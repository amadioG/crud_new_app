<!DOCTYPE html>
<html>
<head>
    <title>Cadastrar Aluno</title>
</head>
<body>
    <h1>Cadastrar Novo Aluno</h1>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <form action="<?php echo e(route('alunos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>
        <br>

        <label for="idade">Idade:</label>
        <input type="number" id="idade" name="idade" required min="1">
        <br>

        <label for="sexo">Sexo:</label>
        <select id="sexo" name="sexo" required>
            <option value="Masculino">Masculino</option>
            <option value="Feminino">Feminino</option>
        </select>
        <br>

        <label for="cpf">CPF:</label>
        <input type="text" id="cpf" name="cpf" required>
        <br>

        <label for="rg">RG:</label>
        <input type="text" id="rg" name="rg" required>
        <br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <br>

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required>
        <br>

        <button type="submit">Cadastrar</button>
    </form>

    <a href="<?php echo e(route('alunos.index')); ?>">Voltar para a lista de alunos</a>
</body>
</html>
<?php /**PATH C:\laragon\www\config\resources\views/CreateAluno.blade.php ENDPATH**/ ?>