<!DOCTYPE html>
<html>
<head>
    <title>Lista de Disciplinas</title>
</head>
<body>
    <h1>Lista de Disciplinas</h1>

    <h2>Detalhes das Disciplinas</h2>
    <ul>
        <?php $__currentLoopData = $disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                Nome: <?php echo e($disciplina['nome']); ?>, Professor: <?php echo e($disciplina['professor']); ?>, Escola: <?php echo e($disciplina['escola']); ?>, Quantidade de Alunos: <?php echo e($disciplina['qtd_alunos']); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h2>Nomes das Disciplinas</h2>
    <ul>
        <?php $__currentLoopData = $nomesDisciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($nome); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a href="<?php echo e(route(name: 'disciplinas.create')); ?>">Cadastrar Disciplina</a>
</body>
</html>
<?php /**PATH C:\laragon\www\crud_app\resources\views/ListaDisciplinas.blade.php ENDPATH**/ ?>