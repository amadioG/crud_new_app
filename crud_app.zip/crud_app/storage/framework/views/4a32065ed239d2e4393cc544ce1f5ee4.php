<!DOCTYPE html>
<html>
<head>
    <title>Lista de Alunos</title>
</head>
<body>
    <h1>Lista de Alunos</h1>

    <h2>Detalhes dos Alunos</h2>
    <ul>
        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                Nome: <?php echo e($aluno['nome']); ?>, Idade: <?php echo e($aluno['idade']); ?>, Email: <?php echo e($aluno['email']); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <h2>Nomes dos Alunos</h2>
    <ul>
        <?php $__currentLoopData = $nomeAlunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($nome); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a href="<?php echo e(route('alunos.create')); ?>">Cadastrar aluno</a>
</body>
</html>
<?php /**PATH C:\laragon\www\crud_app\resources\views/ListaAlunos.blade.php ENDPATH**/ ?>